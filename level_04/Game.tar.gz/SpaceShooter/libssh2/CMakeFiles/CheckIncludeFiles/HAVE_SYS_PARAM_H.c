/* */
#include <sys/param.h>


int main(void){return 0;}

