/* */
#include <sys/uio.h>


int main(void){return 0;}

